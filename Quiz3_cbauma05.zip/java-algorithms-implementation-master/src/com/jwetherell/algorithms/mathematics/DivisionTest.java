package com.jwetherell.algorithms.mathematics;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class DivisionTest {
    @Test
    public void testDivision() {
        assertEquals(4, Division.division(8, 2));

    }

    @Test
    public void testDivision2() {
        assertEquals(0, Division.division(2, 0));
    }

    @Test
    public void testDivision3() {
        assertEquals(4, Division.division(8, 2));
    }
}